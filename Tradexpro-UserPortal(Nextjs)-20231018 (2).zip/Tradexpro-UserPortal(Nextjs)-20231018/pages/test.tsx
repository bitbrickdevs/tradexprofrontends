import Geetest from "components/GeeTest";
import React from "react";

const test = () => {
  return (
    <div>
      <Geetest />
    </div>
  );
};

export default test;
